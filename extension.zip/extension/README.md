Balances

Now whenever you're reading horror stories about Donald Trump, you can immediately donate to an organization that will keep him in check! All instances of the word "Trump" will be transformed into links to the donation page of one of several organizations including:

The ACLU
Planned Parenthood
Anti-Defamation League
Border Angels
Boys & Girls Club of America
StayWoke.org
Center for Reproductive Rights
Southern Poverty Law Center



Many organizations taken from the Jezebel link here: (http://jezebel.com/a-list-of-pro-women-pro-immigrant-pro-earth-anti-big-1788752078)